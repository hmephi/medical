import 'package:firebase_auth/firebase_auth.dart';
import 'package:rxdart/rxdart.dart';

class MedicalDirectoryFirebaseUser {
  MedicalDirectoryFirebaseUser(this.user);
  User user;
  bool get loggedIn => user != null;
}

MedicalDirectoryFirebaseUser currentUser;
bool get loggedIn => currentUser?.loggedIn ?? false;
Stream<MedicalDirectoryFirebaseUser> medicalDirectoryFirebaseUserStream() =>
    FirebaseAuth.instance
        .authStateChanges()
        .debounce((user) => user == null && !loggedIn
            ? TimerStream(true, const Duration(seconds: 1))
            : Stream.value(user))
        .map<MedicalDirectoryFirebaseUser>(
            (user) => currentUser = MedicalDirectoryFirebaseUser(user));
