import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'add_listings_record.g.dart';

abstract class AddListingsRecord
    implements Built<AddListingsRecord, AddListingsRecordBuilder> {
  static Serializer<AddListingsRecord> get serializer =>
      _$addListingsRecordSerializer;

  @nullable
  String get image;

  @nullable
  String get companyName;

  @nullable
  String get email;

  @nullable
  String get website;

  @nullable
  String get contactNumbers;

  @nullable
  String get address;

  @nullable
  DocumentReference get likePost;

  @nullable
  DateTime get datelisted;

  @nullable
  DocumentReference get view;

  @nullable
  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference get reference;

  static void _initializeBuilder(AddListingsRecordBuilder builder) => builder
    ..image = ''
    ..companyName = ''
    ..email = ''
    ..website = ''
    ..contactNumbers = ''
    ..address = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('AddListings');

  static Stream<AddListingsRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s)));

  static Future<AddListingsRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s)));

  AddListingsRecord._();
  factory AddListingsRecord([void Function(AddListingsRecordBuilder) updates]) =
      _$AddListingsRecord;

  static AddListingsRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference});
}

Map<String, dynamic> createAddListingsRecordData({
  String image,
  String companyName,
  String email,
  String website,
  String contactNumbers,
  String address,
  DocumentReference likePost,
  DateTime datelisted,
  DocumentReference view,
}) =>
    serializers.toFirestore(
        AddListingsRecord.serializer,
        AddListingsRecord((a) => a
          ..image = image
          ..companyName = companyName
          ..email = email
          ..website = website
          ..contactNumbers = contactNumbers
          ..address = address
          ..likePost = likePost
          ..datelisted = datelisted
          ..view = view));
