// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'add_listings_record.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializer<AddListingsRecord> _$addListingsRecordSerializer =
    new _$AddListingsRecordSerializer();

class _$AddListingsRecordSerializer
    implements StructuredSerializer<AddListingsRecord> {
  @override
  final Iterable<Type> types = const [AddListingsRecord, _$AddListingsRecord];
  @override
  final String wireName = 'AddListingsRecord';

  @override
  Iterable<Object> serialize(Serializers serializers, AddListingsRecord object,
      {FullType specifiedType = FullType.unspecified}) {
    final result = <Object>[];
    Object value;
    value = object.image;
    if (value != null) {
      result
        ..add('image')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.companyName;
    if (value != null) {
      result
        ..add('companyName')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.email;
    if (value != null) {
      result
        ..add('email')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.website;
    if (value != null) {
      result
        ..add('website')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.contactNumbers;
    if (value != null) {
      result
        ..add('contactNumbers')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.address;
    if (value != null) {
      result
        ..add('address')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.likePost;
    if (value != null) {
      result
        ..add('likePost')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType(Object)])));
    }
    value = object.datelisted;
    if (value != null) {
      result
        ..add('datelisted')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(DateTime)));
    }
    value = object.view;
    if (value != null) {
      result
        ..add('view')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType(Object)])));
    }
    value = object.reference;
    if (value != null) {
      result
        ..add('Document__Reference__Field')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType(Object)])));
    }
    return result;
  }

  @override
  AddListingsRecord deserialize(
      Serializers serializers, Iterable<Object> serialized,
      {FullType specifiedType = FullType.unspecified}) {
    final result = new AddListingsRecordBuilder();

    final iterator = serialized.iterator;
    while (iterator.moveNext()) {
      final key = iterator.current as String;
      iterator.moveNext();
      final Object value = iterator.current;
      switch (key) {
        case 'image':
          result.image = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'companyName':
          result.companyName = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'email':
          result.email = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'website':
          result.website = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'contactNumbers':
          result.contactNumbers = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'address':
          result.address = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'likePost':
          result.likePost = serializers.deserialize(value,
                  specifiedType: const FullType(
                      DocumentReference, const [const FullType(Object)]))
              as DocumentReference<Object>;
          break;
        case 'datelisted':
          result.datelisted = serializers.deserialize(value,
              specifiedType: const FullType(DateTime)) as DateTime;
          break;
        case 'view':
          result.view = serializers.deserialize(value,
                  specifiedType: const FullType(
                      DocumentReference, const [const FullType(Object)]))
              as DocumentReference<Object>;
          break;
        case 'Document__Reference__Field':
          result.reference = serializers.deserialize(value,
                  specifiedType: const FullType(
                      DocumentReference, const [const FullType(Object)]))
              as DocumentReference<Object>;
          break;
      }
    }

    return result.build();
  }
}

class _$AddListingsRecord extends AddListingsRecord {
  @override
  final String image;
  @override
  final String companyName;
  @override
  final String email;
  @override
  final String website;
  @override
  final String contactNumbers;
  @override
  final String address;
  @override
  final DocumentReference<Object> likePost;
  @override
  final DateTime datelisted;
  @override
  final DocumentReference<Object> view;
  @override
  final DocumentReference<Object> reference;

  factory _$AddListingsRecord(
          [void Function(AddListingsRecordBuilder) updates]) =>
      (new AddListingsRecordBuilder()..update(updates)).build();

  _$AddListingsRecord._(
      {this.image,
      this.companyName,
      this.email,
      this.website,
      this.contactNumbers,
      this.address,
      this.likePost,
      this.datelisted,
      this.view,
      this.reference})
      : super._();

  @override
  AddListingsRecord rebuild(void Function(AddListingsRecordBuilder) updates) =>
      (toBuilder()..update(updates)).build();

  @override
  AddListingsRecordBuilder toBuilder() =>
      new AddListingsRecordBuilder()..replace(this);

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is AddListingsRecord &&
        image == other.image &&
        companyName == other.companyName &&
        email == other.email &&
        website == other.website &&
        contactNumbers == other.contactNumbers &&
        address == other.address &&
        likePost == other.likePost &&
        datelisted == other.datelisted &&
        view == other.view &&
        reference == other.reference;
  }

  @override
  int get hashCode {
    return $jf($jc(
        $jc(
            $jc(
                $jc(
                    $jc(
                        $jc(
                            $jc(
                                $jc(
                                    $jc($jc(0, image.hashCode),
                                        companyName.hashCode),
                                    email.hashCode),
                                website.hashCode),
                            contactNumbers.hashCode),
                        address.hashCode),
                    likePost.hashCode),
                datelisted.hashCode),
            view.hashCode),
        reference.hashCode));
  }

  @override
  String toString() {
    return (newBuiltValueToStringHelper('AddListingsRecord')
          ..add('image', image)
          ..add('companyName', companyName)
          ..add('email', email)
          ..add('website', website)
          ..add('contactNumbers', contactNumbers)
          ..add('address', address)
          ..add('likePost', likePost)
          ..add('datelisted', datelisted)
          ..add('view', view)
          ..add('reference', reference))
        .toString();
  }
}

class AddListingsRecordBuilder
    implements Builder<AddListingsRecord, AddListingsRecordBuilder> {
  _$AddListingsRecord _$v;

  String _image;
  String get image => _$this._image;
  set image(String image) => _$this._image = image;

  String _companyName;
  String get companyName => _$this._companyName;
  set companyName(String companyName) => _$this._companyName = companyName;

  String _email;
  String get email => _$this._email;
  set email(String email) => _$this._email = email;

  String _website;
  String get website => _$this._website;
  set website(String website) => _$this._website = website;

  String _contactNumbers;
  String get contactNumbers => _$this._contactNumbers;
  set contactNumbers(String contactNumbers) =>
      _$this._contactNumbers = contactNumbers;

  String _address;
  String get address => _$this._address;
  set address(String address) => _$this._address = address;

  DocumentReference<Object> _likePost;
  DocumentReference<Object> get likePost => _$this._likePost;
  set likePost(DocumentReference<Object> likePost) =>
      _$this._likePost = likePost;

  DateTime _datelisted;
  DateTime get datelisted => _$this._datelisted;
  set datelisted(DateTime datelisted) => _$this._datelisted = datelisted;

  DocumentReference<Object> _view;
  DocumentReference<Object> get view => _$this._view;
  set view(DocumentReference<Object> view) => _$this._view = view;

  DocumentReference<Object> _reference;
  DocumentReference<Object> get reference => _$this._reference;
  set reference(DocumentReference<Object> reference) =>
      _$this._reference = reference;

  AddListingsRecordBuilder() {
    AddListingsRecord._initializeBuilder(this);
  }

  AddListingsRecordBuilder get _$this {
    final $v = _$v;
    if ($v != null) {
      _image = $v.image;
      _companyName = $v.companyName;
      _email = $v.email;
      _website = $v.website;
      _contactNumbers = $v.contactNumbers;
      _address = $v.address;
      _likePost = $v.likePost;
      _datelisted = $v.datelisted;
      _view = $v.view;
      _reference = $v.reference;
      _$v = null;
    }
    return this;
  }

  @override
  void replace(AddListingsRecord other) {
    ArgumentError.checkNotNull(other, 'other');
    _$v = other as _$AddListingsRecord;
  }

  @override
  void update(void Function(AddListingsRecordBuilder) updates) {
    if (updates != null) updates(this);
  }

  @override
  _$AddListingsRecord build() {
    final _$result = _$v ??
        new _$AddListingsRecord._(
            image: image,
            companyName: companyName,
            email: email,
            website: website,
            contactNumbers: contactNumbers,
            address: address,
            likePost: likePost,
            datelisted: datelisted,
            view: view,
            reference: reference);
    replace(_$result);
    return _$result;
  }
}

// ignore_for_file: always_put_control_body_on_new_line,always_specify_types,annotate_overrides,avoid_annotating_with_dynamic,avoid_as,avoid_catches_without_on_clauses,avoid_returning_this,deprecated_member_use_from_same_package,lines_longer_than_80_chars,omit_local_variable_types,prefer_expression_function_bodies,sort_constructors_first,test_types_in_equals,unnecessary_const,unnecessary_new
