import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'adds_record.g.dart';

abstract class AddsRecord implements Built<AddsRecord, AddsRecordBuilder> {
  static Serializer<AddsRecord> get serializer => _$addsRecordSerializer;

  @nullable
  String get website;

  @nullable
  String get logo;

  @nullable
  String get aboutUS;

  @nullable
  String get address;

  @nullable
  String get email;

  @nullable
  String get fax;

  @nullable
  String get telephone;

  @nullable
  int get pleaseSelect;

  @nullable
  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference get reference;

  static void _initializeBuilder(AddsRecordBuilder builder) => builder
    ..website = ''
    ..logo = ''
    ..aboutUS = ''
    ..address = ''
    ..email = ''
    ..fax = ''
    ..telephone = ''
    ..pleaseSelect = 0;

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('adds');

  static Stream<AddsRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s)));

  static Future<AddsRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s)));

  AddsRecord._();
  factory AddsRecord([void Function(AddsRecordBuilder) updates]) = _$AddsRecord;

  static AddsRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference});
}

Map<String, dynamic> createAddsRecordData({
  String website,
  String logo,
  String aboutUS,
  String address,
  String email,
  String fax,
  String telephone,
  int pleaseSelect,
}) =>
    serializers.toFirestore(
        AddsRecord.serializer,
        AddsRecord((a) => a
          ..website = website
          ..logo = logo
          ..aboutUS = aboutUS
          ..address = address
          ..email = email
          ..fax = fax
          ..telephone = telephone
          ..pleaseSelect = pleaseSelect));
