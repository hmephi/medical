// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'adds_record.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializer<AddsRecord> _$addsRecordSerializer = new _$AddsRecordSerializer();

class _$AddsRecordSerializer implements StructuredSerializer<AddsRecord> {
  @override
  final Iterable<Type> types = const [AddsRecord, _$AddsRecord];
  @override
  final String wireName = 'AddsRecord';

  @override
  Iterable<Object> serialize(Serializers serializers, AddsRecord object,
      {FullType specifiedType = FullType.unspecified}) {
    final result = <Object>[];
    Object value;
    value = object.website;
    if (value != null) {
      result
        ..add('website')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.logo;
    if (value != null) {
      result
        ..add('logo')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.aboutUS;
    if (value != null) {
      result
        ..add('aboutUS')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.address;
    if (value != null) {
      result
        ..add('address')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.email;
    if (value != null) {
      result
        ..add('email')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.fax;
    if (value != null) {
      result
        ..add('fax')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.telephone;
    if (value != null) {
      result
        ..add('telephone')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.pleaseSelect;
    if (value != null) {
      result
        ..add('pleaseSelect')
        ..add(serializers.serialize(value, specifiedType: const FullType(int)));
    }
    value = object.reference;
    if (value != null) {
      result
        ..add('Document__Reference__Field')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType(Object)])));
    }
    return result;
  }

  @override
  AddsRecord deserialize(Serializers serializers, Iterable<Object> serialized,
      {FullType specifiedType = FullType.unspecified}) {
    final result = new AddsRecordBuilder();

    final iterator = serialized.iterator;
    while (iterator.moveNext()) {
      final key = iterator.current as String;
      iterator.moveNext();
      final Object value = iterator.current;
      switch (key) {
        case 'website':
          result.website = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'logo':
          result.logo = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'aboutUS':
          result.aboutUS = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'address':
          result.address = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'email':
          result.email = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'fax':
          result.fax = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'telephone':
          result.telephone = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'pleaseSelect':
          result.pleaseSelect = serializers.deserialize(value,
              specifiedType: const FullType(int)) as int;
          break;
        case 'Document__Reference__Field':
          result.reference = serializers.deserialize(value,
                  specifiedType: const FullType(
                      DocumentReference, const [const FullType(Object)]))
              as DocumentReference<Object>;
          break;
      }
    }

    return result.build();
  }
}

class _$AddsRecord extends AddsRecord {
  @override
  final String website;
  @override
  final String logo;
  @override
  final String aboutUS;
  @override
  final String address;
  @override
  final String email;
  @override
  final String fax;
  @override
  final String telephone;
  @override
  final int pleaseSelect;
  @override
  final DocumentReference<Object> reference;

  factory _$AddsRecord([void Function(AddsRecordBuilder) updates]) =>
      (new AddsRecordBuilder()..update(updates)).build();

  _$AddsRecord._(
      {this.website,
      this.logo,
      this.aboutUS,
      this.address,
      this.email,
      this.fax,
      this.telephone,
      this.pleaseSelect,
      this.reference})
      : super._();

  @override
  AddsRecord rebuild(void Function(AddsRecordBuilder) updates) =>
      (toBuilder()..update(updates)).build();

  @override
  AddsRecordBuilder toBuilder() => new AddsRecordBuilder()..replace(this);

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is AddsRecord &&
        website == other.website &&
        logo == other.logo &&
        aboutUS == other.aboutUS &&
        address == other.address &&
        email == other.email &&
        fax == other.fax &&
        telephone == other.telephone &&
        pleaseSelect == other.pleaseSelect &&
        reference == other.reference;
  }

  @override
  int get hashCode {
    return $jf($jc(
        $jc(
            $jc(
                $jc(
                    $jc(
                        $jc(
                            $jc($jc($jc(0, website.hashCode), logo.hashCode),
                                aboutUS.hashCode),
                            address.hashCode),
                        email.hashCode),
                    fax.hashCode),
                telephone.hashCode),
            pleaseSelect.hashCode),
        reference.hashCode));
  }

  @override
  String toString() {
    return (newBuiltValueToStringHelper('AddsRecord')
          ..add('website', website)
          ..add('logo', logo)
          ..add('aboutUS', aboutUS)
          ..add('address', address)
          ..add('email', email)
          ..add('fax', fax)
          ..add('telephone', telephone)
          ..add('pleaseSelect', pleaseSelect)
          ..add('reference', reference))
        .toString();
  }
}

class AddsRecordBuilder implements Builder<AddsRecord, AddsRecordBuilder> {
  _$AddsRecord _$v;

  String _website;
  String get website => _$this._website;
  set website(String website) => _$this._website = website;

  String _logo;
  String get logo => _$this._logo;
  set logo(String logo) => _$this._logo = logo;

  String _aboutUS;
  String get aboutUS => _$this._aboutUS;
  set aboutUS(String aboutUS) => _$this._aboutUS = aboutUS;

  String _address;
  String get address => _$this._address;
  set address(String address) => _$this._address = address;

  String _email;
  String get email => _$this._email;
  set email(String email) => _$this._email = email;

  String _fax;
  String get fax => _$this._fax;
  set fax(String fax) => _$this._fax = fax;

  String _telephone;
  String get telephone => _$this._telephone;
  set telephone(String telephone) => _$this._telephone = telephone;

  int _pleaseSelect;
  int get pleaseSelect => _$this._pleaseSelect;
  set pleaseSelect(int pleaseSelect) => _$this._pleaseSelect = pleaseSelect;

  DocumentReference<Object> _reference;
  DocumentReference<Object> get reference => _$this._reference;
  set reference(DocumentReference<Object> reference) =>
      _$this._reference = reference;

  AddsRecordBuilder() {
    AddsRecord._initializeBuilder(this);
  }

  AddsRecordBuilder get _$this {
    final $v = _$v;
    if ($v != null) {
      _website = $v.website;
      _logo = $v.logo;
      _aboutUS = $v.aboutUS;
      _address = $v.address;
      _email = $v.email;
      _fax = $v.fax;
      _telephone = $v.telephone;
      _pleaseSelect = $v.pleaseSelect;
      _reference = $v.reference;
      _$v = null;
    }
    return this;
  }

  @override
  void replace(AddsRecord other) {
    ArgumentError.checkNotNull(other, 'other');
    _$v = other as _$AddsRecord;
  }

  @override
  void update(void Function(AddsRecordBuilder) updates) {
    if (updates != null) updates(this);
  }

  @override
  _$AddsRecord build() {
    final _$result = _$v ??
        new _$AddsRecord._(
            website: website,
            logo: logo,
            aboutUS: aboutUS,
            address: address,
            email: email,
            fax: fax,
            telephone: telephone,
            pleaseSelect: pleaseSelect,
            reference: reference);
    replace(_$result);
    return _$result;
  }
}

// ignore_for_file: always_put_control_body_on_new_line,always_specify_types,annotate_overrides,avoid_annotating_with_dynamic,avoid_as,avoid_catches_without_on_clauses,avoid_returning_this,deprecated_member_use_from_same_package,lines_longer_than_80_chars,omit_local_variable_types,prefer_expression_function_bodies,sort_constructors_first,test_types_in_equals,unnecessary_const,unnecessary_new
