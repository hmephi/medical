import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'categories_list_record.g.dart';

abstract class CategoriesListRecord
    implements Built<CategoriesListRecord, CategoriesListRecordBuilder> {
  static Serializer<CategoriesListRecord> get serializer =>
      _$categoriesListRecordSerializer;

  @nullable
  String get id;

  @nullable
  String get name;

  @nullable
  String get ratio;

  @nullable
  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference get reference;

  static void _initializeBuilder(CategoriesListRecordBuilder builder) => builder
    ..id = ''
    ..name = ''
    ..ratio = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('categoriesList');

  static Stream<CategoriesListRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s)));

  static Future<CategoriesListRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then(
          (s) => serializers.deserializeWith(serializer, serializedData(s)));

  CategoriesListRecord._();
  factory CategoriesListRecord(
          [void Function(CategoriesListRecordBuilder) updates]) =
      _$CategoriesListRecord;

  static CategoriesListRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference});
}

Map<String, dynamic> createCategoriesListRecordData({
  String id,
  String name,
  String ratio,
}) =>
    serializers.toFirestore(
        CategoriesListRecord.serializer,
        CategoriesListRecord((c) => c
          ..id = id
          ..name = name
          ..ratio = ratio));
