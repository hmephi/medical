import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'featured_companies_record.g.dart';

abstract class FeaturedCompaniesRecord
    implements Built<FeaturedCompaniesRecord, FeaturedCompaniesRecordBuilder> {
  static Serializer<FeaturedCompaniesRecord> get serializer =>
      _$featuredCompaniesRecordSerializer;

  @nullable
  String get logo;

  @nullable
  String get name;

  @nullable
  String get address;

  @nullable
  @BuiltValueField(wireName: 'about_us')
  String get aboutUs;

  @nullable
  String get province;

  @nullable
  DocumentReference get comRef;

  @nullable
  String get telephone;

  @nullable
  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference get reference;

  static void _initializeBuilder(FeaturedCompaniesRecordBuilder builder) =>
      builder
        ..logo = ''
        ..name = ''
        ..address = ''
        ..aboutUs = ''
        ..province = ''
        ..telephone = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('featuredCompanies');

  static Stream<FeaturedCompaniesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map(
          (s) => serializers.deserializeWith(serializer, serializedData(s)));

  static Future<FeaturedCompaniesRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then(
          (s) => serializers.deserializeWith(serializer, serializedData(s)));

  FeaturedCompaniesRecord._();
  factory FeaturedCompaniesRecord(
          [void Function(FeaturedCompaniesRecordBuilder) updates]) =
      _$FeaturedCompaniesRecord;

  static FeaturedCompaniesRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference});
}

Map<String, dynamic> createFeaturedCompaniesRecordData({
  String logo,
  String name,
  String address,
  String aboutUs,
  String province,
  DocumentReference comRef,
  String telephone,
}) =>
    serializers.toFirestore(
        FeaturedCompaniesRecord.serializer,
        FeaturedCompaniesRecord((f) => f
          ..logo = logo
          ..name = name
          ..address = address
          ..aboutUs = aboutUs
          ..province = province
          ..comRef = comRef
          ..telephone = telephone));
