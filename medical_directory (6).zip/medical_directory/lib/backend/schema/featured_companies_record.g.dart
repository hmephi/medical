// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'featured_companies_record.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializer<FeaturedCompaniesRecord> _$featuredCompaniesRecordSerializer =
    new _$FeaturedCompaniesRecordSerializer();

class _$FeaturedCompaniesRecordSerializer
    implements StructuredSerializer<FeaturedCompaniesRecord> {
  @override
  final Iterable<Type> types = const [
    FeaturedCompaniesRecord,
    _$FeaturedCompaniesRecord
  ];
  @override
  final String wireName = 'FeaturedCompaniesRecord';

  @override
  Iterable<Object> serialize(
      Serializers serializers, FeaturedCompaniesRecord object,
      {FullType specifiedType = FullType.unspecified}) {
    final result = <Object>[];
    Object value;
    value = object.logo;
    if (value != null) {
      result
        ..add('logo')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.name;
    if (value != null) {
      result
        ..add('name')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.address;
    if (value != null) {
      result
        ..add('address')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.aboutUs;
    if (value != null) {
      result
        ..add('about_us')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.province;
    if (value != null) {
      result
        ..add('province')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.comRef;
    if (value != null) {
      result
        ..add('comRef')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType(Object)])));
    }
    value = object.telephone;
    if (value != null) {
      result
        ..add('telephone')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.reference;
    if (value != null) {
      result
        ..add('Document__Reference__Field')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType(Object)])));
    }
    return result;
  }

  @override
  FeaturedCompaniesRecord deserialize(
      Serializers serializers, Iterable<Object> serialized,
      {FullType specifiedType = FullType.unspecified}) {
    final result = new FeaturedCompaniesRecordBuilder();

    final iterator = serialized.iterator;
    while (iterator.moveNext()) {
      final key = iterator.current as String;
      iterator.moveNext();
      final Object value = iterator.current;
      switch (key) {
        case 'logo':
          result.logo = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'name':
          result.name = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'address':
          result.address = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'about_us':
          result.aboutUs = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'province':
          result.province = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'comRef':
          result.comRef = serializers.deserialize(value,
                  specifiedType: const FullType(
                      DocumentReference, const [const FullType(Object)]))
              as DocumentReference<Object>;
          break;
        case 'telephone':
          result.telephone = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'Document__Reference__Field':
          result.reference = serializers.deserialize(value,
                  specifiedType: const FullType(
                      DocumentReference, const [const FullType(Object)]))
              as DocumentReference<Object>;
          break;
      }
    }

    return result.build();
  }
}

class _$FeaturedCompaniesRecord extends FeaturedCompaniesRecord {
  @override
  final String logo;
  @override
  final String name;
  @override
  final String address;
  @override
  final String aboutUs;
  @override
  final String province;
  @override
  final DocumentReference<Object> comRef;
  @override
  final String telephone;
  @override
  final DocumentReference<Object> reference;

  factory _$FeaturedCompaniesRecord(
          [void Function(FeaturedCompaniesRecordBuilder) updates]) =>
      (new FeaturedCompaniesRecordBuilder()..update(updates)).build();

  _$FeaturedCompaniesRecord._(
      {this.logo,
      this.name,
      this.address,
      this.aboutUs,
      this.province,
      this.comRef,
      this.telephone,
      this.reference})
      : super._();

  @override
  FeaturedCompaniesRecord rebuild(
          void Function(FeaturedCompaniesRecordBuilder) updates) =>
      (toBuilder()..update(updates)).build();

  @override
  FeaturedCompaniesRecordBuilder toBuilder() =>
      new FeaturedCompaniesRecordBuilder()..replace(this);

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is FeaturedCompaniesRecord &&
        logo == other.logo &&
        name == other.name &&
        address == other.address &&
        aboutUs == other.aboutUs &&
        province == other.province &&
        comRef == other.comRef &&
        telephone == other.telephone &&
        reference == other.reference;
  }

  @override
  int get hashCode {
    return $jf($jc(
        $jc(
            $jc(
                $jc(
                    $jc(
                        $jc($jc($jc(0, logo.hashCode), name.hashCode),
                            address.hashCode),
                        aboutUs.hashCode),
                    province.hashCode),
                comRef.hashCode),
            telephone.hashCode),
        reference.hashCode));
  }

  @override
  String toString() {
    return (newBuiltValueToStringHelper('FeaturedCompaniesRecord')
          ..add('logo', logo)
          ..add('name', name)
          ..add('address', address)
          ..add('aboutUs', aboutUs)
          ..add('province', province)
          ..add('comRef', comRef)
          ..add('telephone', telephone)
          ..add('reference', reference))
        .toString();
  }
}

class FeaturedCompaniesRecordBuilder
    implements
        Builder<FeaturedCompaniesRecord, FeaturedCompaniesRecordBuilder> {
  _$FeaturedCompaniesRecord _$v;

  String _logo;
  String get logo => _$this._logo;
  set logo(String logo) => _$this._logo = logo;

  String _name;
  String get name => _$this._name;
  set name(String name) => _$this._name = name;

  String _address;
  String get address => _$this._address;
  set address(String address) => _$this._address = address;

  String _aboutUs;
  String get aboutUs => _$this._aboutUs;
  set aboutUs(String aboutUs) => _$this._aboutUs = aboutUs;

  String _province;
  String get province => _$this._province;
  set province(String province) => _$this._province = province;

  DocumentReference<Object> _comRef;
  DocumentReference<Object> get comRef => _$this._comRef;
  set comRef(DocumentReference<Object> comRef) => _$this._comRef = comRef;

  String _telephone;
  String get telephone => _$this._telephone;
  set telephone(String telephone) => _$this._telephone = telephone;

  DocumentReference<Object> _reference;
  DocumentReference<Object> get reference => _$this._reference;
  set reference(DocumentReference<Object> reference) =>
      _$this._reference = reference;

  FeaturedCompaniesRecordBuilder() {
    FeaturedCompaniesRecord._initializeBuilder(this);
  }

  FeaturedCompaniesRecordBuilder get _$this {
    final $v = _$v;
    if ($v != null) {
      _logo = $v.logo;
      _name = $v.name;
      _address = $v.address;
      _aboutUs = $v.aboutUs;
      _province = $v.province;
      _comRef = $v.comRef;
      _telephone = $v.telephone;
      _reference = $v.reference;
      _$v = null;
    }
    return this;
  }

  @override
  void replace(FeaturedCompaniesRecord other) {
    ArgumentError.checkNotNull(other, 'other');
    _$v = other as _$FeaturedCompaniesRecord;
  }

  @override
  void update(void Function(FeaturedCompaniesRecordBuilder) updates) {
    if (updates != null) updates(this);
  }

  @override
  _$FeaturedCompaniesRecord build() {
    final _$result = _$v ??
        new _$FeaturedCompaniesRecord._(
            logo: logo,
            name: name,
            address: address,
            aboutUs: aboutUs,
            province: province,
            comRef: comRef,
            telephone: telephone,
            reference: reference);
    replace(_$result);
    return _$result;
  }
}

// ignore_for_file: always_put_control_body_on_new_line,always_specify_types,annotate_overrides,avoid_annotating_with_dynamic,avoid_as,avoid_catches_without_on_clauses,avoid_returning_this,deprecated_member_use_from_same_package,lines_longer_than_80_chars,omit_local_variable_types,prefer_expression_function_bodies,sort_constructors_first,test_types_in_equals,unnecessary_const,unnecessary_new
