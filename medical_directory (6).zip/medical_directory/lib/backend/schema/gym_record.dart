import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'gym_record.g.dart';

abstract class GymRecord implements Built<GymRecord, GymRecordBuilder> {
  static Serializer<GymRecord> get serializer => _$gymRecordSerializer;

  @nullable
  String get image;

  @nullable
  bool get likes;

  @nullable
  String get description;

  @nullable
  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference get reference;

  DocumentReference get parentReference => reference.parent.parent;

  static void _initializeBuilder(GymRecordBuilder builder) => builder
    ..image = ''
    ..likes = false
    ..description = '';

  static Query<Map<String, dynamic>> collection([DocumentReference parent]) =>
      parent != null
          ? parent.collection('gym')
          : FirebaseFirestore.instance.collectionGroup('gym');

  static DocumentReference createDoc(DocumentReference parent) =>
      parent.collection('gym').doc();

  static Stream<GymRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s)));

  static Future<GymRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s)));

  GymRecord._();
  factory GymRecord([void Function(GymRecordBuilder) updates]) = _$GymRecord;

  static GymRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference});
}

Map<String, dynamic> createGymRecordData({
  String image,
  bool likes,
  String description,
}) =>
    serializers.toFirestore(
        GymRecord.serializer,
        GymRecord((g) => g
          ..image = image
          ..likes = likes
          ..description = description));
