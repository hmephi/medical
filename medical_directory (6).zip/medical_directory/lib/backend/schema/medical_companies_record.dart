import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'medical_companies_record.g.dart';

abstract class MedicalCompaniesRecord
    implements Built<MedicalCompaniesRecord, MedicalCompaniesRecordBuilder> {
  static Serializer<MedicalCompaniesRecord> get serializer =>
      _$medicalCompaniesRecordSerializer;

  @nullable
  String get name;

  @nullable
  @BuiltValueField(wireName: 'about_us')
  String get aboutUs;

  @nullable
  String get email;

  @nullable
  String get address;

  @nullable
  String get url;

  @nullable
  String get telephone;

  @nullable
  String get fax;

  @nullable
  DocumentReference get id;

  @nullable
  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference get reference;

  static void _initializeBuilder(MedicalCompaniesRecordBuilder builder) =>
      builder
        ..name = ''
        ..aboutUs = ''
        ..email = ''
        ..address = ''
        ..url = ''
        ..telephone = ''
        ..fax = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('medicalCompanies');

  static Stream<MedicalCompaniesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map(
          (s) => serializers.deserializeWith(serializer, serializedData(s)));

  static Future<MedicalCompaniesRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then(
          (s) => serializers.deserializeWith(serializer, serializedData(s)));

  MedicalCompaniesRecord._();
  factory MedicalCompaniesRecord(
          [void Function(MedicalCompaniesRecordBuilder) updates]) =
      _$MedicalCompaniesRecord;

  static MedicalCompaniesRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference});
}

Map<String, dynamic> createMedicalCompaniesRecordData({
  String name,
  String aboutUs,
  String email,
  String address,
  String url,
  String telephone,
  String fax,
  DocumentReference id,
}) =>
    serializers.toFirestore(
        MedicalCompaniesRecord.serializer,
        MedicalCompaniesRecord((m) => m
          ..name = name
          ..aboutUs = aboutUs
          ..email = email
          ..address = address
          ..url = url
          ..telephone = telephone
          ..fax = fax
          ..id = id));
