// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'medical_companies_record.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializer<MedicalCompaniesRecord> _$medicalCompaniesRecordSerializer =
    new _$MedicalCompaniesRecordSerializer();

class _$MedicalCompaniesRecordSerializer
    implements StructuredSerializer<MedicalCompaniesRecord> {
  @override
  final Iterable<Type> types = const [
    MedicalCompaniesRecord,
    _$MedicalCompaniesRecord
  ];
  @override
  final String wireName = 'MedicalCompaniesRecord';

  @override
  Iterable<Object> serialize(
      Serializers serializers, MedicalCompaniesRecord object,
      {FullType specifiedType = FullType.unspecified}) {
    final result = <Object>[];
    Object value;
    value = object.name;
    if (value != null) {
      result
        ..add('name')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.aboutUs;
    if (value != null) {
      result
        ..add('about_us')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.email;
    if (value != null) {
      result
        ..add('email')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.address;
    if (value != null) {
      result
        ..add('address')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.url;
    if (value != null) {
      result
        ..add('url')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.telephone;
    if (value != null) {
      result
        ..add('telephone')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.fax;
    if (value != null) {
      result
        ..add('fax')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.id;
    if (value != null) {
      result
        ..add('id')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType(Object)])));
    }
    value = object.reference;
    if (value != null) {
      result
        ..add('Document__Reference__Field')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType(Object)])));
    }
    return result;
  }

  @override
  MedicalCompaniesRecord deserialize(
      Serializers serializers, Iterable<Object> serialized,
      {FullType specifiedType = FullType.unspecified}) {
    final result = new MedicalCompaniesRecordBuilder();

    final iterator = serialized.iterator;
    while (iterator.moveNext()) {
      final key = iterator.current as String;
      iterator.moveNext();
      final Object value = iterator.current;
      switch (key) {
        case 'name':
          result.name = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'about_us':
          result.aboutUs = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'email':
          result.email = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'address':
          result.address = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'url':
          result.url = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'telephone':
          result.telephone = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'fax':
          result.fax = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'id':
          result.id = serializers.deserialize(value,
                  specifiedType: const FullType(
                      DocumentReference, const [const FullType(Object)]))
              as DocumentReference<Object>;
          break;
        case 'Document__Reference__Field':
          result.reference = serializers.deserialize(value,
                  specifiedType: const FullType(
                      DocumentReference, const [const FullType(Object)]))
              as DocumentReference<Object>;
          break;
      }
    }

    return result.build();
  }
}

class _$MedicalCompaniesRecord extends MedicalCompaniesRecord {
  @override
  final String name;
  @override
  final String aboutUs;
  @override
  final String email;
  @override
  final String address;
  @override
  final String url;
  @override
  final String telephone;
  @override
  final String fax;
  @override
  final DocumentReference<Object> id;
  @override
  final DocumentReference<Object> reference;

  factory _$MedicalCompaniesRecord(
          [void Function(MedicalCompaniesRecordBuilder) updates]) =>
      (new MedicalCompaniesRecordBuilder()..update(updates)).build();

  _$MedicalCompaniesRecord._(
      {this.name,
      this.aboutUs,
      this.email,
      this.address,
      this.url,
      this.telephone,
      this.fax,
      this.id,
      this.reference})
      : super._();

  @override
  MedicalCompaniesRecord rebuild(
          void Function(MedicalCompaniesRecordBuilder) updates) =>
      (toBuilder()..update(updates)).build();

  @override
  MedicalCompaniesRecordBuilder toBuilder() =>
      new MedicalCompaniesRecordBuilder()..replace(this);

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is MedicalCompaniesRecord &&
        name == other.name &&
        aboutUs == other.aboutUs &&
        email == other.email &&
        address == other.address &&
        url == other.url &&
        telephone == other.telephone &&
        fax == other.fax &&
        id == other.id &&
        reference == other.reference;
  }

  @override
  int get hashCode {
    return $jf($jc(
        $jc(
            $jc(
                $jc(
                    $jc(
                        $jc(
                            $jc($jc($jc(0, name.hashCode), aboutUs.hashCode),
                                email.hashCode),
                            address.hashCode),
                        url.hashCode),
                    telephone.hashCode),
                fax.hashCode),
            id.hashCode),
        reference.hashCode));
  }

  @override
  String toString() {
    return (newBuiltValueToStringHelper('MedicalCompaniesRecord')
          ..add('name', name)
          ..add('aboutUs', aboutUs)
          ..add('email', email)
          ..add('address', address)
          ..add('url', url)
          ..add('telephone', telephone)
          ..add('fax', fax)
          ..add('id', id)
          ..add('reference', reference))
        .toString();
  }
}

class MedicalCompaniesRecordBuilder
    implements Builder<MedicalCompaniesRecord, MedicalCompaniesRecordBuilder> {
  _$MedicalCompaniesRecord _$v;

  String _name;
  String get name => _$this._name;
  set name(String name) => _$this._name = name;

  String _aboutUs;
  String get aboutUs => _$this._aboutUs;
  set aboutUs(String aboutUs) => _$this._aboutUs = aboutUs;

  String _email;
  String get email => _$this._email;
  set email(String email) => _$this._email = email;

  String _address;
  String get address => _$this._address;
  set address(String address) => _$this._address = address;

  String _url;
  String get url => _$this._url;
  set url(String url) => _$this._url = url;

  String _telephone;
  String get telephone => _$this._telephone;
  set telephone(String telephone) => _$this._telephone = telephone;

  String _fax;
  String get fax => _$this._fax;
  set fax(String fax) => _$this._fax = fax;

  DocumentReference<Object> _id;
  DocumentReference<Object> get id => _$this._id;
  set id(DocumentReference<Object> id) => _$this._id = id;

  DocumentReference<Object> _reference;
  DocumentReference<Object> get reference => _$this._reference;
  set reference(DocumentReference<Object> reference) =>
      _$this._reference = reference;

  MedicalCompaniesRecordBuilder() {
    MedicalCompaniesRecord._initializeBuilder(this);
  }

  MedicalCompaniesRecordBuilder get _$this {
    final $v = _$v;
    if ($v != null) {
      _name = $v.name;
      _aboutUs = $v.aboutUs;
      _email = $v.email;
      _address = $v.address;
      _url = $v.url;
      _telephone = $v.telephone;
      _fax = $v.fax;
      _id = $v.id;
      _reference = $v.reference;
      _$v = null;
    }
    return this;
  }

  @override
  void replace(MedicalCompaniesRecord other) {
    ArgumentError.checkNotNull(other, 'other');
    _$v = other as _$MedicalCompaniesRecord;
  }

  @override
  void update(void Function(MedicalCompaniesRecordBuilder) updates) {
    if (updates != null) updates(this);
  }

  @override
  _$MedicalCompaniesRecord build() {
    final _$result = _$v ??
        new _$MedicalCompaniesRecord._(
            name: name,
            aboutUs: aboutUs,
            email: email,
            address: address,
            url: url,
            telephone: telephone,
            fax: fax,
            id: id,
            reference: reference);
    replace(_$result);
    return _$result;
  }
}

// ignore_for_file: always_put_control_body_on_new_line,always_specify_types,annotate_overrides,avoid_annotating_with_dynamic,avoid_as,avoid_catches_without_on_clauses,avoid_returning_this,deprecated_member_use_from_same_package,lines_longer_than_80_chars,omit_local_variable_types,prefer_expression_function_bodies,sort_constructors_first,test_types_in_equals,unnecessary_const,unnecessary_new
