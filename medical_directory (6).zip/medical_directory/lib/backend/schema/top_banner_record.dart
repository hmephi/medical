import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'top_banner_record.g.dart';

abstract class TopBannerRecord
    implements Built<TopBannerRecord, TopBannerRecordBuilder> {
  static Serializer<TopBannerRecord> get serializer =>
      _$topBannerRecordSerializer;

  @nullable
  String get bannerimage;

  @nullable
  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference get reference;

  static void _initializeBuilder(TopBannerRecordBuilder builder) =>
      builder..bannerimage = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('topBanner');

  static Stream<TopBannerRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s)));

  static Future<TopBannerRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s)));

  TopBannerRecord._();
  factory TopBannerRecord([void Function(TopBannerRecordBuilder) updates]) =
      _$TopBannerRecord;

  static TopBannerRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference});
}

Map<String, dynamic> createTopBannerRecordData({
  String bannerimage,
}) =>
    serializers.toFirestore(TopBannerRecord.serializer,
        TopBannerRecord((t) => t..bannerimage = bannerimage));
