import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'updateapp_record.g.dart';

abstract class UpdateappRecord
    implements Built<UpdateappRecord, UpdateappRecordBuilder> {
  static Serializer<UpdateappRecord> get serializer =>
      _$updateappRecordSerializer;

  @nullable
  String get image;

  @nullable
  String get description;

  @nullable
  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference get reference;

  static void _initializeBuilder(UpdateappRecordBuilder builder) => builder
    ..image = ''
    ..description = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('updateapp');

  static Stream<UpdateappRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s)));

  static Future<UpdateappRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s)));

  UpdateappRecord._();
  factory UpdateappRecord([void Function(UpdateappRecordBuilder) updates]) =
      _$UpdateappRecord;

  static UpdateappRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference});
}

Map<String, dynamic> createUpdateappRecordData({
  String image,
  String description,
}) =>
    serializers.toFirestore(
        UpdateappRecord.serializer,
        UpdateappRecord((u) => u
          ..image = image
          ..description = description));
