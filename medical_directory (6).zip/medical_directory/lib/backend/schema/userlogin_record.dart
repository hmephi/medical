import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'userlogin_record.g.dart';

abstract class UserloginRecord
    implements Built<UserloginRecord, UserloginRecordBuilder> {
  static Serializer<UserloginRecord> get serializer =>
      _$userloginRecordSerializer;

  @nullable
  String get username;

  @nullable
  String get password;

  @nullable
  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference get reference;

  static void _initializeBuilder(UserloginRecordBuilder builder) => builder
    ..username = ''
    ..password = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('userlogin');

  static Stream<UserloginRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s)));

  static Future<UserloginRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s)));

  UserloginRecord._();
  factory UserloginRecord([void Function(UserloginRecordBuilder) updates]) =
      _$UserloginRecord;

  static UserloginRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference});
}

Map<String, dynamic> createUserloginRecordData({
  String username,
  String password,
}) =>
    serializers.toFirestore(
        UserloginRecord.serializer,
        UserloginRecord((u) => u
          ..username = username
          ..password = password));
