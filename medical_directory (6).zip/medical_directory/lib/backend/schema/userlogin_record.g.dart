// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'userlogin_record.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializer<UserloginRecord> _$userloginRecordSerializer =
    new _$UserloginRecordSerializer();

class _$UserloginRecordSerializer
    implements StructuredSerializer<UserloginRecord> {
  @override
  final Iterable<Type> types = const [UserloginRecord, _$UserloginRecord];
  @override
  final String wireName = 'UserloginRecord';

  @override
  Iterable<Object> serialize(Serializers serializers, UserloginRecord object,
      {FullType specifiedType = FullType.unspecified}) {
    final result = <Object>[];
    Object value;
    value = object.username;
    if (value != null) {
      result
        ..add('username')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.password;
    if (value != null) {
      result
        ..add('password')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.reference;
    if (value != null) {
      result
        ..add('Document__Reference__Field')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType(Object)])));
    }
    return result;
  }

  @override
  UserloginRecord deserialize(
      Serializers serializers, Iterable<Object> serialized,
      {FullType specifiedType = FullType.unspecified}) {
    final result = new UserloginRecordBuilder();

    final iterator = serialized.iterator;
    while (iterator.moveNext()) {
      final key = iterator.current as String;
      iterator.moveNext();
      final Object value = iterator.current;
      switch (key) {
        case 'username':
          result.username = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'password':
          result.password = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'Document__Reference__Field':
          result.reference = serializers.deserialize(value,
                  specifiedType: const FullType(
                      DocumentReference, const [const FullType(Object)]))
              as DocumentReference<Object>;
          break;
      }
    }

    return result.build();
  }
}

class _$UserloginRecord extends UserloginRecord {
  @override
  final String username;
  @override
  final String password;
  @override
  final DocumentReference<Object> reference;

  factory _$UserloginRecord([void Function(UserloginRecordBuilder) updates]) =>
      (new UserloginRecordBuilder()..update(updates)).build();

  _$UserloginRecord._({this.username, this.password, this.reference})
      : super._();

  @override
  UserloginRecord rebuild(void Function(UserloginRecordBuilder) updates) =>
      (toBuilder()..update(updates)).build();

  @override
  UserloginRecordBuilder toBuilder() =>
      new UserloginRecordBuilder()..replace(this);

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is UserloginRecord &&
        username == other.username &&
        password == other.password &&
        reference == other.reference;
  }

  @override
  int get hashCode {
    return $jf($jc(
        $jc($jc(0, username.hashCode), password.hashCode), reference.hashCode));
  }

  @override
  String toString() {
    return (newBuiltValueToStringHelper('UserloginRecord')
          ..add('username', username)
          ..add('password', password)
          ..add('reference', reference))
        .toString();
  }
}

class UserloginRecordBuilder
    implements Builder<UserloginRecord, UserloginRecordBuilder> {
  _$UserloginRecord _$v;

  String _username;
  String get username => _$this._username;
  set username(String username) => _$this._username = username;

  String _password;
  String get password => _$this._password;
  set password(String password) => _$this._password = password;

  DocumentReference<Object> _reference;
  DocumentReference<Object> get reference => _$this._reference;
  set reference(DocumentReference<Object> reference) =>
      _$this._reference = reference;

  UserloginRecordBuilder() {
    UserloginRecord._initializeBuilder(this);
  }

  UserloginRecordBuilder get _$this {
    final $v = _$v;
    if ($v != null) {
      _username = $v.username;
      _password = $v.password;
      _reference = $v.reference;
      _$v = null;
    }
    return this;
  }

  @override
  void replace(UserloginRecord other) {
    ArgumentError.checkNotNull(other, 'other');
    _$v = other as _$UserloginRecord;
  }

  @override
  void update(void Function(UserloginRecordBuilder) updates) {
    if (updates != null) updates(this);
  }

  @override
  _$UserloginRecord build() {
    final _$result = _$v ??
        new _$UserloginRecord._(
            username: username, password: password, reference: reference);
    replace(_$result);
    return _$result;
  }
}

// ignore_for_file: always_put_control_body_on_new_line,always_specify_types,annotate_overrides,avoid_annotating_with_dynamic,avoid_as,avoid_catches_without_on_clauses,avoid_returning_this,deprecated_member_use_from_same_package,lines_longer_than_80_chars,omit_local_variable_types,prefer_expression_function_bodies,sort_constructors_first,test_types_in_equals,unnecessary_const,unnecessary_new
