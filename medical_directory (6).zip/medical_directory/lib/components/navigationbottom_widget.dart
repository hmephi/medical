import '../aboutus/aboutus_widget.dart';
import '../components/press_widget.dart';
import '../flutter_flow/flutter_flow_animations.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../global_medical_news/global_medical_news_widget.dart';
import '../loginmaster/loginmaster_widget.dart';
import '../main.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class NavigationbottomWidget extends StatefulWidget {
  const NavigationbottomWidget({Key key}) : super(key: key);

  @override
  _NavigationbottomWidgetState createState() => _NavigationbottomWidgetState();
}

class _NavigationbottomWidgetState extends State<NavigationbottomWidget>
    with TickerProviderStateMixin {
  final animationsMap = {
    'columnOnPageLoadAnimation': AnimationInfo(
      curve: Curves.easeIn,
      trigger: AnimationTrigger.onPageLoad,
      duration: 1790,
      delay: 670,
      hideBeforeAnimating: true,
      fadeIn: true,
      initialState: AnimationState(
        offset: Offset(0, 70),
        scale: 1,
        opacity: 0,
      ),
      finalState: AnimationState(
        offset: Offset(0, 0),
        scale: 1,
        opacity: 1,
      ),
    ),
  };

  @override
  void initState() {
    super.initState();
    startPageLoadAnimations(
      animationsMap.values
          .where((anim) => anim.trigger == AnimationTrigger.onPageLoad),
      this,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(0, 15, 25, 0),
      child: Material(
        color: Colors.transparent,
        elevation: 5,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(0),
            bottomRight: Radius.circular(0),
            topLeft: Radius.circular(25),
            topRight: Radius.circular(50),
          ),
        ),
        child: Container(
          width: double.infinity,
          height: 700,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(0),
              bottomRight: Radius.circular(0),
              topLeft: Radius.circular(25),
              topRight: Radius.circular(50),
            ),
          ),
          child: Container(
            width: double.infinity,
            decoration: BoxDecoration(
              image: DecorationImage(
                fit: BoxFit.cover,
                image: Image.asset(
                  'assets/images/vecteezy_flat-design-abstract-background-soft-liquid-shapes-template_.jpg',
                ).image,
              ),
              boxShadow: [
                BoxShadow(
                  blurRadius: 3,
                  color: Color(0x32000000),
                  offset: Offset(0, 1),
                )
              ],
              gradient: LinearGradient(
                colors: [Colors.red, Color(0xFF3CC040)],
                stops: [1, 1],
                begin: AlignmentDirectional(0, -1),
                end: AlignmentDirectional(0, 1),
              ),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(0),
                bottomRight: Radius.circular(0),
                topLeft: Radius.circular(0),
                topRight: Radius.circular(55),
              ),
            ),
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0, 20, 0, 0),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(44, 24, 24, 16),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(0, 0, 5, 0),
                          child: Icon(
                            Icons.home,
                            color: Color(0xFF635AB5),
                            size: 24,
                          ),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(12, 0, 0, 0),
                              child: InkWell(
                                onTap: () async {
                                  await Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) =>
                                          NavBarPage(initialPage: 'HomePage'),
                                    ),
                                  );
                                },
                                child: Text(
                                  'Home',
                                  style: FlutterFlowTheme.of(context)
                                      .title1
                                      .override(
                                        fontFamily: 'Oswald',
                                        color: Color(0xB9171717),
                                        fontSize: 20,
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Divider(
                    height: 4,
                    thickness: 2,
                    indent: 20,
                    endIndent: 20,
                    color: Color(0xFF635AB5),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(44, 24, 24, 16),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Icon(
                          Icons.question_answer,
                          color: Color(0xFF635AB5),
                          size: 24,
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(12, 0, 0, 0),
                              child: InkWell(
                                onTap: () async {
                                  await Navigator.push(
                                    context,
                                    PageTransition(
                                      type: PageTransitionType.rightToLeft,
                                      duration: Duration(milliseconds: 1500),
                                      reverseDuration:
                                          Duration(milliseconds: 1500),
                                      child: AboutusWidget(),
                                    ),
                                  );
                                },
                                child: Text(
                                  'About us',
                                  style: FlutterFlowTheme.of(context)
                                      .title1
                                      .override(
                                        fontFamily: 'Oswald',
                                        color: Color(0xB9171717),
                                        fontSize: 20,
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Divider(
                    height: 4,
                    thickness: 2,
                    indent: 20,
                    endIndent: 20,
                    color: Color(0xFF635AB5),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(44, 24, 24, 16),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Icon(
                          Icons.speaker_group_outlined,
                          color: Color(0xFF635AB5),
                          size: 24,
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(12, 0, 0, 0),
                              child: InkWell(
                                onTap: () async {
                                  await showModalBottomSheet(
                                    isScrollControlled: true,
                                    backgroundColor: Colors.transparent,
                                    context: context,
                                    builder: (context) {
                                      return Padding(
                                        padding:
                                            MediaQuery.of(context).viewInsets,
                                        child: PressWidget(),
                                      );
                                    },
                                  );
                                },
                                child: Text(
                                  'Press Relese',
                                  style: FlutterFlowTheme.of(context)
                                      .title1
                                      .override(
                                        fontFamily: 'Oswald',
                                        color: Color(0xB9171717),
                                        fontSize: 20,
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Divider(
                    height: 4,
                    thickness: 2,
                    indent: 20,
                    endIndent: 20,
                    color: Color(0xFF635AB5),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(44, 24, 24, 16),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Icon(
                          Icons.account_tree_rounded,
                          color: Color(0xFF635AB5),
                          size: 24,
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(12, 0, 0, 0),
                              child: InkWell(
                                onTap: () async {
                                  await Navigator.push(
                                    context,
                                    PageTransition(
                                      type: PageTransitionType.rightToLeft,
                                      duration: Duration(milliseconds: 1500),
                                      reverseDuration:
                                          Duration(milliseconds: 1500),
                                      child: NavBarPage(
                                          initialPage: 'Listingsview'),
                                    ),
                                  );
                                },
                                child: Text(
                                  'View Listings',
                                  style: FlutterFlowTheme.of(context)
                                      .title1
                                      .override(
                                        fontFamily: 'Oswald',
                                        color: Color(0xB9171717),
                                        fontSize: 20,
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Divider(
                    height: 4,
                    thickness: 2,
                    indent: 20,
                    endIndent: 20,
                    color: Color(0xFF635AB5),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(44, 24, 24, 16),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Icon(
                          Icons.account_tree_outlined,
                          color: Color(0xFF635AB5),
                          size: 24,
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(12, 0, 0, 0),
                              child: InkWell(
                                onTap: () async {
                                  await Navigator.push(
                                    context,
                                    PageTransition(
                                      type: PageTransitionType.rightToLeft,
                                      duration: Duration(milliseconds: 1500),
                                      reverseDuration:
                                          Duration(milliseconds: 1500),
                                      child: NavBarPage(initialPage: 'login'),
                                    ),
                                  );
                                },
                                child: Text(
                                  'Add Listings',
                                  style: FlutterFlowTheme.of(context)
                                      .title1
                                      .override(
                                        fontFamily: 'Oswald',
                                        color: Color(0xB9171717),
                                        fontSize: 20,
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Divider(
                    height: 4,
                    thickness: 2,
                    indent: 20,
                    endIndent: 20,
                    color: Color(0xFF635AB5),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(44, 24, 24, 16),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Icon(
                          Icons.speaker_notes_rounded,
                          color: Color(0xFF635AB5),
                          size: 24,
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(12, 0, 0, 0),
                              child: InkWell(
                                onTap: () async {
                                  await Navigator.push(
                                    context,
                                    PageTransition(
                                      type: PageTransitionType.leftToRight,
                                      duration: Duration(milliseconds: 1500),
                                      reverseDuration:
                                          Duration(milliseconds: 1500),
                                      child: GlobalMedicalNewsWidget(),
                                    ),
                                  );
                                },
                                child: Text(
                                  'Global News',
                                  style: FlutterFlowTheme.of(context)
                                      .title1
                                      .override(
                                        fontFamily: 'Oswald',
                                        color: Color(0xB9171717),
                                        fontSize: 20,
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Divider(
                    height: 4,
                    thickness: 2,
                    indent: 20,
                    endIndent: 20,
                    color: Color(0xFF635AB5),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(44, 24, 24, 16),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Icon(
                          Icons.perm_phone_msg,
                          color: Color(0xFF635AB5),
                          size: 24,
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(12, 0, 0, 0),
                              child: Text(
                                'Contact us',
                                style: FlutterFlowTheme.of(context)
                                    .title1
                                    .override(
                                      fontFamily: 'Oswald',
                                      color: Color(0xB9171717),
                                      fontSize: 20,
                                      fontWeight: FontWeight.w600,
                                    ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Divider(
                    height: 4,
                    thickness: 2,
                    indent: 20,
                    endIndent: 20,
                    color: Color(0xFF635AB5),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(44, 24, 24, 16),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Icon(
                          Icons.login,
                          color: Color(0xFF635AB5),
                          size: 24,
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(12, 0, 0, 0),
                              child: InkWell(
                                onTap: () async {
                                  await Navigator.push(
                                    context,
                                    PageTransition(
                                      type: PageTransitionType.bottomToTop,
                                      duration: Duration(milliseconds: 2000),
                                      reverseDuration:
                                          Duration(milliseconds: 2000),
                                      child: LoginmasterWidget(),
                                    ),
                                  );
                                },
                                child: Text(
                                  'Login',
                                  style: FlutterFlowTheme.of(context)
                                      .title1
                                      .override(
                                        fontFamily: 'Oswald',
                                        color: Color(0xB9171717),
                                        fontSize: 20,
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Divider(
                    height: 4,
                    thickness: 2,
                    indent: 20,
                    endIndent: 20,
                    color: Color(0xFF635AB5),
                  ),
                ],
              ).animated([animationsMap['columnOnPageLoadAnimation']]),
            ),
          ),
        ),
      ),
    );
  }
}
