import '../flutter_flow/flutter_flow_animations.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../flutter_flow/flutter_flow_web_view.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class PressWidget extends StatefulWidget {
  const PressWidget({Key key}) : super(key: key);

  @override
  _PressWidgetState createState() => _PressWidgetState();
}

class _PressWidgetState extends State<PressWidget>
    with TickerProviderStateMixin {
  final animationsMap = {
    'webViewOnPageLoadAnimation': AnimationInfo(
      curve: Curves.easeIn,
      trigger: AnimationTrigger.onPageLoad,
      duration: 1260,
      hideBeforeAnimating: true,
      fadeIn: true,
      initialState: AnimationState(
        offset: Offset(0, 0),
        scale: 1,
        opacity: 0,
      ),
      finalState: AnimationState(
        offset: Offset(0, 0),
        scale: 1,
        opacity: 1,
      ),
    ),
  };

  @override
  void initState() {
    super.initState();
    startPageLoadAnimations(
      animationsMap.values
          .where((anim) => anim.trigger == AnimationTrigger.onPageLoad),
      this,
    );
  }

  @override
  Widget build(BuildContext context) {
    return FlutterFlowWebView(
      url: 'https://adsproof.com/david/gov_one/pages/view/press',
      bypass: false,
      height: 700,
      verticalScroll: false,
      horizontalScroll: false,
    ).animated([animationsMap['webViewOnPageLoadAnimation']]);
  }
}
