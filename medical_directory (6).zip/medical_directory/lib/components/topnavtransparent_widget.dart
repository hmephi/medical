import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class TopnavtransparentWidget extends StatefulWidget {
  const TopnavtransparentWidget({Key key}) : super(key: key);

  @override
  _TopnavtransparentWidgetState createState() =>
      _TopnavtransparentWidgetState();
}

class _TopnavtransparentWidgetState extends State<TopnavtransparentWidget> {
  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(0, -1),
      child: Image.asset(
        'assets/images/hand-holds-phone-female-doctor-s-contact-online-consultation-doctor-concept-safety-home-quarantine-medical-180931890.jpg',
        width: double.infinity,
        height: 350,
        fit: BoxFit.cover,
      ),
    );
  }
}
